<div style="color:#000;margin-top:20px;margin-left:auto;margin-right:auto;max-width:800px;background-color:#F4F4F4">
  <table style="font-family: Helvetica Neue,Helvetica,Arial, sans-serif; font-size:13px;background: #F4F4F4; width: 100%; border: 4px solid #bbbbbb;" cellpadding="10" cellspacing="5">
    <tbody>
      <tr>
        <th style="background-color:#ccc; font-size:16px;padding:5px;border-bottom:2px solid #fff;"> <a href="[SITEURL]">[LOGO]</a></th>
      </tr>
      <tr>
        <td style="text-align: left;background-color:#F4F4F4" valign="top">Hello <b>Admin</b>,<br />
          <br />
          Your Client at [COMPANY] has submitted a new message. Please login to the Admin Area to view this message.</td>
      </tr>
      <tr>
        <td style="text-align: left;background-color:#F4F4F4" valign="top"><b>Contact Summary:</b><br />
          <br />
          <table style="font-family: Helvetica Neue,Helvetica,Arial, sans-serif; font-size:13px;" border="0" cellpadding="5" cellspacing="2" width="100%">
            <tbody>
              <tr>
                <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;" width="150">Client Name:</td>
                <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[NAME]</td>
              </tr>
              <tr>
                <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Client Email:</td>
                <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[EMAIL]</td>
              </tr>
              <tr>
                <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Email Subject:</td>
                <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[SUBJECT]</td>
              </tr>
              <tr>
                <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Message:</td>
                <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[MESSAGE]</td>
              </tr>
            </tbody>
          </table></td>
      </tr>
      <tr>
        <td style="text-align: center; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;font-size:12px" valign="top"> This email is sent to you directly from <a href="[SITEURL]">[COMPANY]</a> The information above is gathered from the user input. <br />
          &copy;[DATE] <a href="[SITEURL]">[COMPANY]</a>. All rights reserved.</td>
      </tr>
    </tbody>
  </table>
</div>