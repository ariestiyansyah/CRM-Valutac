<div style="color:#000;margin-top:20px;margin-left:auto;margin-right:auto;max-width:800px;background-color:#F4F4F4">
  <table style="font-family: Helvetica Neue,Helvetica,Arial, sans-serif; font-size:13px;background: #F4F4F4; width: 100%; border: 4px solid #bbbbbb;" cellpadding="10" cellspacing="5">
    <tr>
      <th style="background-color:#ccc; font-size:16px;padding:5px;border-bottom-width:2px; border-bottom-color:#fff; border-bottom-style:solid"> <a href="[SITEURL]">[LOGO]</a></th>
    </tr>
    <tr>
      <td style="text-align: left;" valign="top">Hello <strong>[STAFF_NAME]</strong>,<br/>
        <br/>
        Your Client at [COMPANY] has submitted a new submission for your review. Please login to the Admin Area to view this submission.</td>
    </tr>
    <tr>
      <td style="text-align: left;" valign="top"><strong>Submission Summary:</strong><br>
        <br>
        <table width="100%" border="0" cellpadding="5" cellspacing="2" style="font-family: Helvetica Neue,Helvetica,Arial, sans-serif; font-size:13px;">
          <tr>
            <td width="150" style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Project Name:</td>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[PTITLE]</td>
          </tr>
          <tr>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Submission Name</td>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[STITLE]</td>
          </tr>
          <tr>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Client Name</td>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[NAME]</td>
          </tr>
          <tr>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Review:</td>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[CONTENT]</td>
          </tr>
        </table></td>
    </tr>
    <tr>
      <td style="text-align: left;" valign="top"><em>Thank You,<br/>
        <a href="[SITEURL]">[COMPANY]</a></em></td>
    </tr>
    <tr>
      <td style="text-align: center; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;font-size:12px" valign="top"> This email is sent to you directly from <a href="[SITEURL]">[COMPANY]</a> The information above is gathered from the user input. <br />
        &copy;[DATE] <a href="[SITEURL]">[COMPANY]</a>. All rights reserved.</td>
    </tr>
      </tbody>
    
  </table>
</div>
