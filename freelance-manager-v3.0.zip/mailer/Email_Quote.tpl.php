<div style="color:#000;margin-top:20px;margin-left:auto;margin-right:auto;max-width:1200px;background-color:#fff">
  <table width="100%" border="0" cellpadding="0" cellspacing="0" style="font-family: Helvetica Neue,Helvetica,Arial, sans-serif; font-size:13px;">
    <tr>
      <td style="background-color:#33527B;padding:0 5px;height:10px"></td>
      <td width="250" style="background-color:#7C8083;padding:0 5px"></td>
    </tr>
  </table>
  <table width="100%" border="0" cellpadding="0" cellspacing="0" style="font-family: Helvetica Neue,Helvetica,Arial, sans-serif; font-size:13px;">
    <tr>
      <td valign="top" style="padding:5px"><a href="[SITEURL]">[LOGO]</a></td>
      <td width="250" valign="top" style="padding:5px"><h4 style="margin:0px;padding:0px;font-size: 14px;">Quote: #[QUTID]</h4>
        <h4 style="margin:0px;padding:0px;font-size: 14px;">Quote Date: [DATE]</h4></td>
    </tr>
  </table>
  <div style="height:20px"></div>
  <table width="100%" border="0" cellpadding="0" cellspacing="0" style="font-family: Helvetica Neue,Helvetica,Arial, sans-serif; font-size:13px;">
    <tr>
      <td valign="top" style="padding:5px"><strong>Payment To</strong></td>
      <td colspan="2" valign="top" style="padding:5px"><strong>Bill To</strong></td>
    </tr>
    <tr>
      <td valign="top" style="padding:5px"><h2 style="font-size: 18px; margin: 0px; padding: 0px;">[COMPANY]</h2>
        [ADDRESS]<br />
        [ADDRESS2]<br />
        [PHONE]<br />
        [FAX]</td>
      <td width="250" colspan="2" valign="top" style="padding:5px"><h2 style="font-size: 18px; margin: 0px; padding: 0px;">[NAME]</h2>
        [CCOMPANY]<br />
        [CADDRESS]<br />
        [CADDRESS2]<br />
        [CPHONE]</td>
    </tr>
    <tr>
      <td colspan="3" valign="top" style="padding:5px"><div style="background-color:#7C8083;height:3px">&nbsp;</div></td>
    </tr>
    <tr>
      <td valign="top" style="padding:5px">Business Number: [TAXNUMBER]
        [VAT]</td>
      <td width="130" valign="top" style="padding:5px"><strong>Quote Total:<br />
        Expires:</strong></td>
      <td width="100" valign="top" style="padding:5px"><strong>[AMTOUNT]<br />
        [EXPIRE]</strong></td>
    </tr>
  </table>
  <div style="height:20px"></div>
  <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-bottom-width: 4px; border-left-width: 1px; border-bottom-style: solid; border-left-style: solid; border-bottom-color: #7C8083; border-left-color: #7C8083;font-family: Helvetica Neue,Helvetica,Arial, sans-serif; font-size:13px;">
    <tr>
      <td valign="top" style="background-color:#7C8083;padding:5px;border-right-width: 1px; border-right-style: solid; border-right-color: #7C8083; border-top-width: 1px; border-top-style: solid; border-top-color: #7C8083;"><strong style="color:white">Quote Items</strong></td>
      <td align="right" valign="top" style="background-color:#7C8083;padding:5px;border-right-width: 1px; border-right-style: solid; border-right-color: #7C8083; border-top-width: 1px; border-top-style: solid; border-top-color: #7C8083;"><strong style="color:white">Price</strong></td>
    </tr>
  </table>
  <div> [QUOTEDATA] </div>
  <div style="height:20px"></div>
  <div style="font-size:11px;font-family: Helvetica Neue,Helvetica,Arial, sans-serif;padding:10px">[NOTES]</div>
</div>
