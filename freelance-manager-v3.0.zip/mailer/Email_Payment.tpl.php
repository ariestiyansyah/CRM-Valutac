<div style="color:#000;margin-top:20px;margin-left:auto;margin-right:auto;max-width:800px;background-color:#F4F4F4">
  <table style="font-family: Helvetica Neue,Helvetica,Arial, sans-serif; font-size:13px;background: #F4F4F4; width: 100%; border: 4px solid #bbbbbb;" cellpadding="10" cellspacing="5">
    <tr>
      <th style="background-color:#ccc; font-size:16px;padding:5px;border-bottom-width:2px; border-bottom-color:#fff; border-bottom-style:solid"> <a href="[SITEURL]">[LOGO]</a></th>
    </tr>
    <tr>
      <td align="left" valign="top" style="padding:5px;text-align: left;"><strong>Dear [UNAME], </strong> <br>
        <br>
        Thank you for your payment. See the details below:</td>
    </tr>
    <tr>
      <td style="text-align: left;" valign="top"><strong>Payment Summary:</strong><br>
        <br>
        <table width="100%" border="0" cellpadding="5" cellspacing="2" style="font-family: Helvetica Neue,Helvetica,Arial, sans-serif; font-size:13px;">
          <tr>
            <td width="150" style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Project Name:</td>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[PTITLE]</td>
          </tr>
          <tr>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Invoice #</td>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[INVID]</td>
          </tr>
          <tr>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Invoice Name:</td>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[TITLE]</td>
          </tr>
          <tr>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Payment Amount:</td>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[GROSS]</td>
          </tr>
          <tr>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Amount Due:</td>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[TOTAL]</td>
          </tr>
          <tr>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Payment Date:</td>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[DATE]</td>
          </tr>
          <tr>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">Payment Processor:</td>
            <td style="text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;">[METHOD]</td>
          </tr>
        </table></td>
    </tr>
    <tr>
      <td style="text-align: center; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid;font-size:12px" valign="top"> This email is sent to you directly from <a href="[SITEURL]">[COMPANY]</a> The information above is gathered from the user input. <br />
        &copy;[DATE] <a href="[SITEURL]">[COMPANY]</a>. All rights reserved.</td>
    </tr>
  </table>
</div>
