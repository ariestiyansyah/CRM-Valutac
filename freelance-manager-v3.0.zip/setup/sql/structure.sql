-- ================================================================
--
-- @version $Id: structure.sql 2011-12-27 10:12:05 gewa $
-- @package Freelance Manager
-- @copyright 2014. wojoscripts.com
--
-- ================================================================
-- Database structure
-- ================================================================

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sesid` varchar(60) NOT NULL DEFAULT '0',
  `form_id` int(4) NOT NULL DEFAULT '0',
  `price` decimal(9,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `parent_id`, `name`) VALUES
(1, 0, 'Albania'),
(2, 0, 'Algeria'),
(3, 0, 'American Samoa'),
(4, 0, 'Andorra'),
(5, 0, 'Angola'),
(6, 0, 'Anguilla'),
(7, 0, 'Antigua'),
(8, 0, 'Antilles'),
(9, 0, 'Argentina'),
(10, 0, 'Armenia'),
(11, 0, 'Aruba'),
(12, 0, 'Australia'),
(13, 0, 'Austria'),
(14, 0, 'Azerbaijan'),
(15, 0, 'Azores'),
(16, 0, 'Bahamas'),
(17, 0, 'Bahrain'),
(18, 0, 'Bangladesh'),
(19, 0, 'Barbados'),
(20, 0, 'Barbuda'),
(21, 0, 'Belgium'),
(22, 0, 'Belize'),
(23, 0, 'Belorus'),
(24, 0, 'Benin'),
(25, 0, 'Bermuda'),
(26, 0, 'Bhutan'),
(27, 0, 'Bolivia'),
(28, 0, 'Bonaire'),
(29, 0, 'Bosnia &amp; Hercegovina'),
(30, 0, 'Botswana'),
(31, 0, 'Br. Virgin Islands'),
(32, 0, 'Brazil'),
(33, 0, 'Brunei'),
(34, 0, 'Bulgaria'),
(35, 0, 'Burkina Faso'),
(36, 0, 'Burundi'),
(37, 0, 'Caicos Island'),
(38, 0, 'Cameroon'),
(39, 0, 'Canada'),
(40, 0, 'Canary Islands'),
(41, 0, 'Cape Verde'),
(42, 0, 'Cayman Islands'),
(43, 0, 'Central African Republic'),
(44, 0, 'Chad'),
(45, 0, 'Channel Islands'),
(46, 0, 'Chile'),
(47, 0, 'China'),
(48, 0, 'Colombia'),
(50, 0, 'Congo'),
(51, 0, 'Cook Islands'),
(52, 0, 'Cooper Island'),
(53, 0, 'Costa Rica'),
(54, 0, 'Cote D&#39;Ivoire'),
(55, 0, 'Croatia'),
(56, 0, 'Curacao'),
(57, 0, 'Cyprus'),
(58, 0, 'Czech Republic'),
(59, 0, 'Denmark'),
(60, 0, 'Djibouti'),
(61, 0, 'Dominica'),
(62, 0, 'Dominican Republic'),
(63, 0, 'Ecuador'),
(64, 0, 'Egypt'),
(65, 0, 'El Salvador'),
(66, 0, 'England'),
(67, 0, 'Equatorial Guinea'),
(68, 0, 'Estonia'),
(69, 0, 'Ethiopia'),
(70, 0, 'Fiji'),
(71, 0, 'Finland'),
(72, 0, 'France'),
(73, 0, 'French Guiana'),
(74, 0, 'French Polynesia'),
(75, 0, 'Futuna Island'),
(76, 0, 'Gabon'),
(77, 0, 'Gambia'),
(78, 0, 'Georgia'),
(79, 0, 'Germany'),
(80, 0, 'Ghana'),
(81, 0, 'Gibraltar'),
(82, 0, 'Greece'),
(83, 0, 'Grenada'),
(84, 0, 'Grenland'),
(85, 0, 'Guadeloupe'),
(86, 0, 'Guam'),
(87, 0, 'Guatemala'),
(88, 0, 'Guinea'),
(89, 0, 'Guinea-Bissau'),
(90, 0, 'Guyana'),
(91, 0, 'Haiti'),
(92, 0, 'Holland'),
(93, 0, 'Honduras'),
(94, 0, 'Hong Kong'),
(95, 0, 'Hungary'),
(96, 0, 'Iceland'),
(97, 0, 'India'),
(98, 0, 'Indonesia'),
(99, 0, 'Iran'),
(100, 0, 'Iraq'),
(101, 0, 'Ireland, Northern'),
(102, 0, 'Ireland, Republic of'),
(103, 0, 'Isle of Man'),
(104, 0, 'Israel'),
(105, 0, 'Italy'),
(106, 0, 'Ivory Coast'),
(107, 0, 'Jamaica'),
(108, 0, 'Japan'),
(109, 0, 'Jordan'),
(110, 0, 'Jost Van Dyke Island'),
(111, 0, 'Kampuchea'),
(112, 0, 'Kazakhstan'),
(113, 0, 'Kenya'),
(114, 0, 'Kiribati'),
(115, 0, 'Korea'),
(116, 0, 'Korea, South'),
(117, 0, 'Kosrae'),
(118, 0, 'Kuwait'),
(119, 0, 'Kyrgyzstan'),
(120, 0, 'Laos'),
(121, 0, 'Latvia'),
(122, 0, 'Lebanon'),
(123, 0, 'Lesotho'),
(124, 0, 'Liberia'),
(125, 0, 'Liechtenstein'),
(126, 0, 'Lithuania'),
(127, 0, 'Luxembourg'),
(128, 0, 'Macau'),
(129, 0, 'Macedonia'),
(130, 0, 'Madagascar'),
(131, 0, 'Madeira Islands'),
(132, 0, 'Malagasy'),
(133, 0, 'Malawi'),
(134, 0, 'Malaysia'),
(135, 0, 'Maldives'),
(136, 0, 'Mali'),
(137, 0, 'Malta'),
(138, 0, 'Marshall Islands'),
(139, 0, 'Martinique'),
(140, 0, 'Mauritania'),
(141, 0, 'Mauritius'),
(142, 0, 'Mexico'),
(143, 0, 'Micronesia'),
(144, 0, 'Moldova'),
(145, 0, 'Monaco'),
(146, 0, 'Mongolia'),
(147, 0, 'Montenegro'),
(148, 0, 'Montserrat'),
(149, 0, 'Morocco'),
(150, 0, 'Mozambique'),
(151, 0, 'Myanmar'),
(152, 0, 'Namibia'),
(153, 0, 'Nauru'),
(154, 0, 'Nepal'),
(155, 0, 'Netherlands'),
(156, 0, 'Nevis'),
(157, 0, 'Nevis (St. Kitts)'),
(158, 0, 'New Caledonia'),
(159, 0, 'New Zealand'),
(160, 0, 'Nicaragua'),
(161, 0, 'Niger'),
(162, 0, 'Nigeria'),
(163, 0, 'Niue'),
(164, 0, 'Norfolk Island'),
(165, 0, 'Norman Island'),
(166, 0, 'Northern Mariana Island'),
(167, 0, 'Norway'),
(168, 0, 'Oman'),
(169, 0, 'Pakistan'),
(170, 0, 'Palau'),
(171, 0, 'Panama'),
(172, 0, 'Papua New Guinea'),
(173, 0, 'Paraguay'),
(174, 0, 'Peru'),
(175, 0, 'Philippines'),
(176, 0, 'Poland'),
(177, 0, 'Ponape'),
(178, 0, 'Portugal'),
(179, 0, 'Qatar'),
(180, 0, 'Reunion'),
(181, 0, 'Romania'),
(182, 0, 'Rota'),
(183, 0, 'Russia'),
(184, 0, 'Rwanda'),
(185, 0, 'Saba'),
(186, 0, 'Saipan'),
(187, 0, 'San Marino'),
(188, 0, 'Sao Tome'),
(189, 0, 'Saudi Arabia'),
(190, 0, 'Scotland'),
(191, 0, 'Senegal'),
(192, 0, 'Serbia'),
(193, 0, 'Seychelles'),
(194, 0, 'Sierra Leone'),
(195, 0, 'Singapore'),
(196, 0, 'Slovakia'),
(197, 0, 'Slovenia'),
(198, 0, 'Solomon Islands'),
(199, 0, 'Somalia'),
(200, 0, 'South Africa'),
(201, 0, 'Spain'),
(202, 0, 'Sri Lanka'),
(203, 0, 'St. Barthelemy'),
(204, 0, 'St. Christopher'),
(205, 0, 'St. Croix'),
(206, 0, 'St. Eustatius'),
(207, 0, 'St. John'),
(208, 0, 'St. Kitts'),
(209, 0, 'St. Lucia'),
(210, 0, 'St. Maarten'),
(211, 0, 'St. Martin'),
(212, 0, 'St. Thomas'),
(213, 0, 'St. Vincent'),
(214, 0, 'Sudan'),
(215, 0, 'Suriname'),
(216, 0, 'Swaziland'),
(217, 0, 'Sweden'),
(218, 0, 'Switzerland'),
(219, 0, 'Syria'),
(220, 0, 'Tahiti'),
(221, 0, 'Taiwan'),
(222, 0, 'Tajikistan'),
(223, 0, 'Tanzania'),
(224, 0, 'Thailand'),
(225, 0, 'Tinian'),
(226, 0, 'Togo'),
(227, 0, 'Tonaga'),
(228, 0, 'Tonga'),
(229, 0, 'Tortola'),
(230, 0, 'Trinidad and Tobago'),
(231, 0, 'Truk'),
(232, 0, 'Tunisia'),
(233, 0, 'Turkey'),
(234, 0, 'Turkmenistan'),
(235, 0, 'Turks and Caicos Island'),
(236, 0, 'Tuvalu'),
(237, 0, 'U.S. Virgin Islands'),
(238, 0, 'Uganda'),
(239, 0, 'Ukraine'),
(240, 0, 'Union Island'),
(241, 0, 'United Arab Emirates'),
(242, 0, 'United Kingdom'),
(243, 0, 'Uruguay'),
(244, 0, 'United States'),
(245, 0, 'Uzbekistan'),
(246, 0, 'Vanuatu'),
(247, 0, 'Vatican City'),
(248, 0, 'Venezuela'),
(249, 0, 'Vietnam'),
(250, 0, 'Virgin Islands (British)'),
(251, 0, 'Virgin Islands (U.S.)'),
(252, 0, 'Wake Island'),
(253, 0, 'Wales'),
(254, 0, 'Wallis Island'),
(255, 0, 'Western Samoa'),
(256, 0, 'Yap'),
(257, 0, 'Yemen, Republic of'),
(258, 0, 'Zaire'),
(259, 0, 'Zambia'),
(260, 0, 'Zimbabwe');

--
-- Table structure for table `custom_fields`
--

CREATE TABLE IF NOT EXISTS `custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(120) DEFAULT NULL,
  `req` tinyint(1) NOT NULL DEFAULT '0',
  `tooltip` varchar(100) DEFAULT NULL,
  `section` varchar(3) DEFAULT NULL,
  `sorting` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `estimator`
--

CREATE TABLE IF NOT EXISTS `estimator` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `form_data` text,
  `form_html` text,
  `mailto` varchar(50) DEFAULT NULL,
  `captcha` tinyint(1) NOT NULL DEFAULT '0',
  `description` text,
  `sendmessage` varchar(200) DEFAULT NULL,
  `submit_btn` varchar(50) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `showhours` tinyint(1) NOT NULL DEFAULT '1',
  `dpd` decimal(13,2) NOT NULL DEFAULT '120.00',
  `is_service` tinyint(1) NOT NULL DEFAULT '0',
  `gateways` varchar(50) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `estimator_data`
--

CREATE TABLE IF NOT EXISTS `estimator_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` int(11) NOT NULL DEFAULT '0',
  `form_data` text,
  `sesid` varchar(60) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `estimator_fields`
--

CREATE TABLE IF NOT EXISTS `estimator_fields` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `desc` text,
  `msgerror` varchar(200) DEFAULT NULL,
  `tooltip` varchar(200) DEFAULT NULL,
  `type` enum('text','area','radio','check','selbox','datefield','colorfield','filefield','imgfield','labelfield','parafield','hr') DEFAULT NULL,
  `attr` text,
  `defval` varchar(50) DEFAULT NULL,
  `other` varchar(50) DEFAULT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `multiple` tinyint(1) NOT NULL DEFAULT '0',
  `price` varchar(200) DEFAULT NULL,
  `html` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `estimator_layout`
--

CREATE TABLE `estimator_layout` (
  `form_id` int(6) NOT NULL DEFAULT '0',
  `field_id` int(6) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `forms`
--

CREATE TABLE IF NOT EXISTS `forms` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `form_data` text,
  `form_html` text,
  `mailto` varchar(50) DEFAULT NULL,
  `captcha` tinyint(1) NOT NULL DEFAULT '0',
  `sendmessage` varchar(200) DEFAULT NULL,
  `submit_btn` varchar(50) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `forms_data`
--

CREATE TABLE IF NOT EXISTS `forms_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` int(11) NOT NULL DEFAULT '0',
  `form_data` text,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `form_fields`
--

CREATE TABLE IF NOT EXISTS `form_fields` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `desc` text,
  `msgerror` varchar(200) DEFAULT NULL,
  `tooltip` varchar(200) DEFAULT NULL,
  `type` enum('text','area','radio','check','selbox','datefield','colorfield','filefield','imgfield','labelfield','parafield','hr') DEFAULT NULL,
  `attr` text,
  `defval` varchar(50) DEFAULT NULL,
  `other` varchar(50) DEFAULT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `multiple` tinyint(1) NOT NULL DEFAULT '0',
  `html` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `form_layout`
--

CREATE TABLE `form_layout` (
  `form_id` int(6) NOT NULL DEFAULT '0',
  `field_id` int(6) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `gateways`
--

CREATE TABLE IF NOT EXISTS `gateways` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `displayname` varchar(200) NOT NULL,
  `dir` varchar(200) NOT NULL,
  `live` tinyint(1) NOT NULL DEFAULT '0',
  `extra_txt` varchar(200) NOT NULL,
  `extra_txt2` varchar(200) NOT NULL,
  `extra_txt3` varchar(200) DEFAULT NULL,
  `extra` varchar(200) NOT NULL,
  `extra2` varchar(200) NOT NULL,
  `extra3` varchar(200) DEFAULT NULL,
  `info` text,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gateways`
--

INSERT INTO `gateways` (`id`, `name`, `displayname`, `dir`, `live`, `extra_txt`, `extra_txt2`, `extra_txt3`, `extra`, `extra2`, `extra3`, `info`, `active`) VALUES
(1, 'paypal', 'PayPal', 'paypal', 0, 'Paypal Email Address', 'Currency Code', 'Not in Use', 'alex.k_1286769967_biz@gmail.com', '', '', '&lt;p&gt;&lt;a href=&quot;http://www.paypal.com/&quot; title=&quot;PayPal&quot; rel=&quot;nofollow&quot; target=&quot;_blank&quot;&gt;Click here to setup an account with Paypal&lt;/a&gt; &lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;Gateway Name&lt;/strong&gt; - Enter the name of the payment provider here.&lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;Active&lt;/strong&gt; - Select Yes to make this payment provider active. &lt;br/&gt;\r\n			If this box is not checked, the payment provider will not show up in the payment provider list during checkout.&lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;Set Live Mode&lt;/strong&gt; - If you would like to test the payment provider settings, please select No. &lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;Paypal email address&lt;/strong&gt; - Enter your PayPal Business email address here. &lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;Currency Code&lt;/strong&gt; - Enter your currency code here. Valid choices are: &lt;/p&gt;\r\n				&lt;ul&gt;\r\n					&lt;li&gt; USD (U.S. Dollar)&lt;/li&gt;\r\n					&lt;li&gt; EUR (Euro) &lt;/li&gt;\r\n					&lt;li&gt; GBP (Pound Sterling) &lt;/li&gt;\r\n					&lt;li&gt; CAD (Canadian Dollar) &lt;/li&gt;\r\n					&lt;li&gt; JPY (Yen). &lt;/li&gt;\r\n					&lt;li&gt; If omitted, all monetary fields will use default system setting Currency Code. &lt;/li&gt;\r\n				&lt;/ul&gt;\r\n			&lt;p&gt;&lt;strong&gt;Not in Use&lt;/strong&gt; - This field it&#039;s not in use. Leave it empty. &lt;/p&gt;\r\n	        &lt;p&gt;&lt;strong&gt;IPN Url&lt;/strong&gt; - If using recurring payment method, you need to set up and activate the IPN Url in your account: &lt;/p&gt;', 1),
(2, 'moneybookers', 'Skrill', 'moneybookers', 0, 'MoneyBookers Email Address', 'Currency Code', 'Secret Passphrase', 'gewa@rogers.com', 'EUR', 'mypassphrase', '&lt;p&gt;&lt;a href=&quot;http://www.moneybookers.com/&quot; title=&quot;http://www.moneybookers.net/&quot; rel=&quot;nofollow&quot;&gt;Click here to setup an account with MoneyBookers&lt;/a&gt;&lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;Gateway Name&lt;/strong&gt; - Enter the name of the payment provider here.&lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;Active&lt;/strong&gt; - Select Yes to make this payment provider active. &lt;br/&gt;\r\n			If this box is not checked, the payment provider will not show up in the payment provider list during checkout.&lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;Set Live Mode&lt;/strong&gt; - MoneyBookers does not have demo mode. You need to open testing acounts. One seller and one buyer. &lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;MoneyBookers email address&lt;/strong&gt; - Enter your MoneyBookers email address here. &lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;Secret Passphrase&lt;/strong&gt; - This field must be set at Moneybookers.com.&lt;/p&gt;\r\n	        &lt;p&gt;&lt;strong&gt;IPN Url&lt;/strong&gt; - If using recurring payment method, you need to set up and activate the IPN Url in your account: &lt;/p&gt;', 1),
(3, 'payza', 'Payza', 'payza', 0, 'Payza Email Address', 'Currency Code', 'IPN Security Code', 'seller_1_alex.kuzmanovic@gmail.com', 'USD', 'd9vL9oYVOGpmVM2i', '&lt;p&gt;&lt;a href=&quot;http://www.payza.com/&quot; title=&quot;http://www.payza.com/&quot; rel=&quot;nofollow&quot;&gt;Click here to setup an account with Payza&lt;/a&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Gateway Name&lt;/strong&gt; - Enter the name of the payment provider here.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Active&lt;/strong&gt; - Select Yes to make this payment provider active. &lt;br/&gt;\r\n  If this box is not checked, the payment provider will not show up in the payment provider list during checkout.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Set Live Mode&lt;/strong&gt; - If you would like to test the payment provider settings, please select No. &lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;AlertPay email address&lt;/strong&gt; - Enter your Payza email address here. &lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;IPN Security Code&lt;/strong&gt; - This code needs to be generated in your Payza control panel.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;IPN Url&lt;/strong&gt; - This has to be set in the Payza control panel. You will also need to check the &quot;IPN Status&quot; to enabled.&lt;/p&gt;', 1),
(4, 'anet', 'AuthorizeNet', 'anet', 0, 'API Login Id', 'MD5 Hash Key', 'Transaction Key', '49P45fPmgXt', 'gewa0208', '79348xBdzWSwz88m', '&lt;p&gt;&lt;a href=&quot;http://www.authorize.net/&quot; title=&quot;http://www.authorize.net//&quot; rel=&quot;nofollow&quot;&gt;Click here to setup an account with Authorize.Net&lt;/a&gt;&lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;Gateway Name&lt;/strong&gt; - Enter the name of the payment provider here.&lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;Active&lt;/strong&gt; - Select Yes to make this payment provider active. &lt;br/&gt;\r\n			  If this box is not checked, the payment provider will not show up in the payment provider list during checkout.&lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;Set Live Mode&lt;/strong&gt; - If you would like to test the payment provider settings, please select No. &lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;Login ID&lt;/strong&gt; - To obtain your API Login ID:&lt;/p&gt;\r\n			&lt;ol type=&quot;1&quot;&gt;\r\n			  &lt;li&gt; Log into the Merchant Interface at &lt;a href=&quot;https://secure.authorize.net&quot; target=&quot;_blank&quot;&gt;https://secure.authorize.net&lt;/a&gt;&lt;/li&gt;\r\n			  &lt;li&gt; Select Settings under Account in the main menu on the left &lt;/li&gt;\r\n			  &lt;li&gt; Click API Login ID and Transaction Key in the Security Settings section &lt;/li&gt;\r\n			  &lt;li&gt; If you have not already obtained an API Login ID and Transaction Key for your account,&lt;br/&gt;\r\n				you will need to enter the secret answer to the secret question you configured at account activation. &lt;/li&gt;\r\n			  &lt;li&gt; Click Submit. &lt;/li&gt;\r\n			&lt;/ol&gt;\r\n			&lt;p&gt;&lt;strong&gt;MD5 Hash&lt;/strong&gt; - To obtain your MD5 Hash:&lt;/p&gt;\r\n			&lt;ol type=&quot;1&quot;&gt;\r\n			  &lt;li&gt; Log into the Merchant Interface at &lt;a href=&quot;https://secure.authorize.net&quot; target=&quot;_blank&quot;&gt;https://secure.authorize.net&lt;/a&gt;&lt;/li&gt;\r\n			  &lt;li&gt; Select Settings under Account in the main menu on the left &lt;/li&gt;\r\n			  &lt;li&gt; Click MD5 Hash in the Security Settings section &lt;/li&gt;\r\n			  &lt;li&gt;Enter a secret word, phrase, or value and remember this.&lt;/li&gt;\r\n			  &lt;li&gt; Click Submit. &lt;/li&gt;\r\n			&lt;/ol&gt;\r\n			&lt;strong&gt;Transaction Key&lt;/strong&gt; - To obtain a Transaction Key:\r\n			&lt;ol type=&quot;1&quot;&gt;\r\n			  &lt;li&gt; Log on to the Merchant Interface at &lt;a href=&quot;https://secure.authorize.net&quot; target=&quot;_blank&quot;&gt;https://secure.authorize.net&lt;/a&gt;&lt;/li&gt;\r\n			  &lt;li&gt; Select Settings under Account in the main menu on the left &lt;/li&gt;\r\n			  &lt;li&gt; Click API Login ID and Transaction Key in the Security Settings section &lt;/li&gt;\r\n			  &lt;li&gt; Enter the secret answer to the secret question you configured when you activated your user account &lt;/li&gt;\r\n			  &lt;li&gt; Click Submit &lt;/li&gt;\r\n			&lt;/ol&gt;\r\n			&lt;p&gt;The Transaction Key for your account is displayed on a confirmation page.&lt;/p&gt;\r\n			&lt;p&gt;&lt;strong&gt;IPN Url&lt;/strong&gt; - This option it\\&#039;s not being used.&lt;/p&gt;', 1),
(5, 'stripe', 'Stripe', 'stripe', 0, 'Secret Key', 'Currency Code', 'Publishable Key', 'sk_test_6sDE6weBXgEuHbrjZKyG5MlQ', 'CAD', 'pk_test_vRosykAcmL59P2r7H9hziwrg', '&lt;p&gt;&lt;a href=&quot;https://stripe.com/ca&quot; title=&quot;https://stripe.com/ca&quot; rel=&quot;nofollow&quot;&gt;Click here to setup an account with Stripe&lt;/a&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Gateway Name&lt;/strong&gt; - Enter the name of the payment provider here.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Active&lt;/strong&gt; - Select Yes to make this payment provider active. &lt;br&gt;\r\n  If this box is not checked, the payment provider will not show up in the payment provider list during checkout.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Set Live Mode&lt;/strong&gt; - To test Stripe, use your test keys instead of live ones.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;API Keys&lt;/strong&gt; - To obtain your API Keys:&lt;/p&gt;\r\n&lt;ul&gt;\r\n  &lt;li&gt; 1. Log into the Dashboard at &lt;a href=&quot;https://stripe.com/ca&quot; target=&quot;_blank&quot;&gt;https://stripe.com/ca&lt;/a&gt;&lt;/li&gt;\r\n  &lt;li&gt; 2. Select Account Settings under Your Account in the main menu on the left &lt;/li&gt;\r\n  &lt;li&gt; 3. Click API Keys&lt;/li&gt;\r\n  &lt;li&gt; 4. Your keys will be displayed &lt;/li&gt;\r\n\r\n&lt;p&gt;You should use test keys first to verify, that everything is working smoothly, before going live.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;IPN Url&lt;/strong&gt; - This option it&#039;s not being used.&lt;/p&gt;\r\n&lt;/ul&gt;', 1),
(6, '2co', '2 Checkout', '2co', 0, '2CO Account Number', 'Currency Code', 'Secret Word', '1891593', 'USD', 'gewa', '&lt;p&gt;&lt;a href=&quot;https://www.2checkout.com/signup&quot; title=&quot;2CO&quot; rel=&quot;nofollow&quot;&gt;Click here to setup an account with 2CO&lt;/a&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Gateway Name&lt;/strong&gt; - Enter the name of the payment provider here.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Active&lt;/strong&gt; - Select Yes to make this payment provider active. &lt;br&gt;\r\n  If this box is not checked, the payment provider will not show up in the payment provider list during checkout.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Set Live Mode&lt;/strong&gt; - To test 2CO, set this option to Yes&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;2CO Account Number&lt;/strong&gt; - This is your default account number&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Secret Word&lt;/strong&gt; - Your 2CO secret word&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;IPN Url&lt;/strong&gt; - No need to set up INS url in your 2CO account. IPN url will be automatically add to submit form&lt;/p&gt;', 1),
(7, 'payfast', 'PayFast', 'payfast', 0, 'Merchant ID', 'Merchant Key', 'PassPhrase', '10000100', '46f0cd694581a', '', '&lt;p&gt;&lt;a href=&quot;https://www.payfast.co.za/&quot; title=&quot;https://www.payfast.co.za/&quot; rel=&quot;nofollow&quot;&gt;Click here to setup an account with PayFast&lt;/a&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Gateway Name&lt;/strong&gt; - Enter the name of the payment provider here.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Active&lt;/strong&gt; - Select Yes to make this payment provider active. &lt;br&gt;\r\n&lt;p&gt;&lt;strong&gt;PassPhrase&lt;/strong&gt; - ONLY INSERT A VALUE INTO THE SECURE PASSPHRASE IF YOU HAVE SET THIS ON THE INTEGRATION PAGE OF THE LOGGED IN AREA OF THE PAYFAST WEBSITE!!!!!.&lt;/p&gt;\r\nIf this box is not checked, the payment provider will not show up in the payment provider list during checkout.\r\n&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Set Live Mode&lt;/strong&gt; - To test PayFast, use your test keys instead of live ones.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;API Keys&lt;/strong&gt; - To obtain your API Keys:&lt;/p&gt;\r\n&lt;ul&gt;\r\n  &lt;li&gt; 1. Log into the Dashboard at &lt;a href=&quot;https://www.payfast.co.za/user/login&quot; target=&quot;_blank&quot;&gt;https://www.payfast.co.za/user/login&lt;/a&gt;&lt;/li&gt;\r\n  &lt;li&gt; 2. Select Account Settings under Your Account in the main menu on the left &lt;/li&gt;\r\n  &lt;li&gt; 3. Click API Keys&lt;/li&gt;\r\n  &lt;li&gt; 4. Your keys will be displayed &lt;/li&gt;\r\n  &lt;p&gt;You should use test keys first to verify, that everything is working smoothly, before going live.&lt;/p&gt;\r\n  &lt;p&gt;&lt;strong&gt;IPN Url&lt;/strong&gt; - This option it''s not being used.&lt;/p&gt;\r\n&lt;/ul&gt;', 1);

--
-- Table structure for table `invoices`
--

CREATE TABLE IF NOT EXISTS `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `client_id` int(11) NOT NULL DEFAULT '0',
  `created` date NOT NULL,
  `duedate` date NOT NULL,
  `amount_total` decimal(13,2) NOT NULL DEFAULT '0.00',
  `amount_paid` decimal(13,2) NOT NULL DEFAULT '0.00',
  `method` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `tax` decimal(13,2) NOT NULL DEFAULT '0.00',
  `notes` text,
  `comment` varchar(200) DEFAULT NULL,
  `recurring` tinyint(1) NOT NULL DEFAULT '0',
  `onhold` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `invoice_data`
--

CREATE TABLE IF NOT EXISTS `invoice_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(80) NOT NULL,
  `description` text NOT NULL,
  `amount` decimal(13,2) NOT NULL DEFAULT '0.00',
  `recurring` tinyint(1) NOT NULL DEFAULT '0',
  `days` int(2) NOT NULL DEFAULT '0',
  `period` varchar(1) NOT NULL DEFAULT 'D',
  `tax` decimal(13,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `invoice_payments`
--

CREATE TABLE IF NOT EXISTS `invoice_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `method` varchar(20) NOT NULL,
  `amount` decimal(13,2) NOT NULL DEFAULT '0.00',
  `recurring` tinyint(1) NOT NULL DEFAULT '0',
  `created` date NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid1` int(11) NOT NULL DEFAULT '0',
  `uid2` int(11) NOT NULL DEFAULT '0',
  `user1` int(11) NOT NULL DEFAULT '0',
  `user2` int(11) NOT NULL DEFAULT '0',
  `msgsubject` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `attachment` varchar(60) DEFAULT NULL,
  `user1read` varchar(3) DEFAULT NULL,
  `user2read` varchar(3) DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(55) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `body` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `author` varchar(55) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `created` date NOT NULL DEFAULT '0000-00-00',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `txn_id` varchar(100) DEFAULT NULL,
  `form_id` int(11) NOT NULL DEFAULT '0',
  `user` varchar(60) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `price` decimal(9,2) NOT NULL DEFAULT '0.00',
  `currency` varchar(6) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pp` varchar(40) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `staff_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `staff_id` varchar(20) NOT NULL DEFAULT '0',
  `project_type` int(11) NOT NULL DEFAULT '0',
  `title` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `body` text NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `cost` decimal(13,2) NOT NULL DEFAULT '0.00',
  `b_status` decimal(13,2) NOT NULL DEFAULT '0.00',
  `p_status` varchar(3) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `custom_fields` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `project_files`
--

CREATE TABLE IF NOT EXISTS `project_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `project_id` int(11) NOT NULL DEFAULT '0',
  `client_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `filename` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `filedesc` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `filesize` decimal(10,2) NOT NULL,
  `created` datetime NOT NULL,
  `version` varchar(10) NOT NULL DEFAULT '1.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `project_types`
--

CREATE TABLE IF NOT EXISTS `project_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(55) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `quotes`
--

CREATE TABLE IF NOT EXISTS `quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `client_id` int(11) NOT NULL DEFAULT '0',
  `created` date NOT NULL,
  `expire` date NOT NULL,
  `amount_total` decimal(13,2) NOT NULL DEFAULT '0.00',
  `method` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `token` varchar(64) NOT NULL DEFAULT '0',
  `tax` decimal(13,2) NOT NULL DEFAULT '0.00',
  `notes` text,
  `comment` varchar(200) DEFAULT NULL,
  `status` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `quotes_data`
--

CREATE TABLE IF NOT EXISTS `quotes_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `quote_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(80) NOT NULL,
  `description` text NOT NULL,
  `amount` decimal(13,2) NOT NULL DEFAULT '0.00',
  `tax` decimal(13,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `company` varchar(75) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `site_url` varchar(75) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `site_dir` varchar(50) DEFAULT NULL,
  `site_email` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `address` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `city` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `state` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `zip` varchar(16) NOT NULL,
  `country` varchar(100) DEFAULT NULL,
  `phone` varchar(16) DEFAULT NULL,
  `fax` varchar(16) DEFAULT NULL,
  `logo` varchar(60) NOT NULL,
  `short_date` varchar(20) NOT NULL,
  `long_date` varchar(20) NOT NULL,
  `dtz` varchar(200) NOT NULL,
  `lang` varchar(2) NOT NULL DEFAULT 'en',
  `weekstart` tinyint(1) NOT NULL DEFAULT '1',
  `locale` varchar(100) DEFAULT NULL,
  `theme` varchar(30) DEFAULT NULL,
  `unvsfn` tinyint(1) NOT NULL DEFAULT '1',
  `enable_reg` tinyint(1) NOT NULL DEFAULT '1',
  `enable_tax` tinyint(1) NOT NULL DEFAULT '0',
  `tax_name` varchar(55) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `tax_rate` varchar(8) NOT NULL DEFAULT '0',
  `tax_number` varchar(100) DEFAULT NULL,
  `enable_offline` tinyint(1) NOT NULL DEFAULT '1',
  `offline_info` text,
  `invoice_note` text,
  `invoice_number` varchar(40) DEFAULT NULL,
  `quote_number` varchar(40) DEFAULT NULL,
  `enable_uploads` tinyint(1) NOT NULL DEFAULT '1',
  `file_types` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `file_max` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `perpage` varchar(3) NOT NULL DEFAULT '10',
  `sbackup` varchar(50) DEFAULT NULL,
  `currency` varchar(4) DEFAULT NULL,
  `cur_symbol` varchar(6) DEFAULT NULL,
  `tsep` varchar(1) NOT NULL DEFAULT ',',
  `dsep` varchar(1) NOT NULL DEFAULT '.',
  `pp_email` varchar(50) DEFAULT NULL,
  `pp_pass` varchar(30) DEFAULT NULL,
  `pp_api` varchar(100) DEFAULT NULL,
  `pp_mode` tinyint(1) NOT NULL DEFAULT '0',
  `invdays` tinyint(1) NOT NULL DEFAULT '7',
  `pagesize` varchar(10) NOT NULL DEFAULT 'LETTER',
  `mailer` enum('PHP','SMTP','SMAIL') NOT NULL DEFAULT 'PHP',
  `smtp_host` varchar(100) DEFAULT NULL,
  `smtp_user` varchar(50) DEFAULT NULL,
  `smtp_pass` varchar(50) DEFAULT NULL,
  `smtp_port` smallint(3) DEFAULT NULL,
  `sendmail` varchar(60) DEFAULT NULL,
  `is_ssl` tinyint(1) NOT NULL DEFAULT '0',
  `crmv` varchar(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`company`, `site_url`, `site_dir`, `site_email`, `address`, `city`, `state`, `zip`, `country`, `phone`, `fax`, `logo`, `short_date`, `long_date`, `dtz`, `lang`, `weekstart`, `locale`, `theme`, `unvsfn`, `enable_reg`, `enable_tax`, `tax_name`, `tax_rate`, `tax_number`, `enable_offline`, `offline_info`, `invoice_note`, `invoice_number`, `quote_number`, `enable_uploads`, `file_types`, `file_max`, `perpage`, `sbackup`, `currency`, `cur_symbol`, `tsep`, `dsep`, `pp_email`, `pp_pass`, `pp_api`, `pp_mode`, `invdays`, `pagesize`, `mailer`, `smtp_host`, `smtp_user`, `smtp_pass`, `smtp_port`, `sendmail`, `is_ssl`, `crmv`) VALUES
('', '', '', '', '123 Main St.', 'Toronto', 'Ontario', 'M2J 1K5', 'Canada', '555-555-5555', '444-444-4444', 'logo.png', '%m-%d-%Y', '%B %d, %Y %I:%M %p', 'America/Toronto', 'en', 1, 'en_us_utf8,English (US)', 'master', 0, 1, 1, 'HST', '0.13', '123456789-WOJO-321', 1, 'Instructions for offline payments\r\nSuch as bank info, address etc...', 'You can enter here your company policy or any other info', 'RTB-ST5', 'QUO-1010', 1, 'gif,png,jpg,jpeg,pdf,zip,rar', '10485760', '10', '14-Jul-2014_23-23-44.sql', 'CAD', '$', ',', '.', '', '', '', 0, 10, 'LETTER', 'PHP', 'smtp.gmail.com', 'alex.kuzmanovic', 'alex_0208!', 465, '/usr/sbin/sendmail -t -i', 1, '3.00');

--
-- Table structure for table `staff_payment`
--

CREATE TABLE IF NOT EXISTS `staff_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `txn_id` varchar(60) DEFAULT NULL,
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `amount` decimal(13,2) DEFAULT NULL,
  `currency` varchar(6) DEFAULT NULL,
  `note` text,
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `submissions`
--

CREATE TABLE IF NOT EXISTS `submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(4) NOT NULL,
  `staff_id` int(4) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `s_type` varchar(55) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review` text NOT NULL,
  `reviewed` tinyint(1) NOT NULL DEFAULT '0',
  `custom_fields` text,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `support_responses`
--

CREATE TABLE IF NOT EXISTS `support_responses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `user_type` varchar(15) NOT NULL,
  `created` datetime NOT NULL,
  `body` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `support_tickets`
--

CREATE TABLE IF NOT EXISTS `support_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `tid` varchar(30) DEFAULT '0',
  `client_id` int(11) NOT NULL DEFAULT '0',
  `project_id` int(11) NOT NULL DEFAULT '0',
  `department` varchar(50) DEFAULT NULL,
  `priority` varchar(50) DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `body` text,
  `attachment` varchar(60) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `client_access` tinyint(1) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `details` text CHARACTER SET utf8 COLLATE utf8_bin,
  `created` datetime DEFAULT NULL,
  `duedate` datetime DEFAULT NULL,
  `progress` varchar(3) DEFAULT '0',
  `custom_fields` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `task_templates`
--

CREATE TABLE IF NOT EXISTS `task_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `details` text CHARACTER SET utf8 COLLATE utf8_bin,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `time_billing`
--

CREATE TABLE IF NOT EXISTS `time_billing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(8) NOT NULL DEFAULT '0',
  `client_id` int(8) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `task_id` int(8) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '0',
  `description` text,
  `hours` decimal(5,2) NOT NULL DEFAULT '0.00',
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pp_email` varchar(50) DEFAULT NULL,
  `fname` varchar(32) NOT NULL,
  `lname` varchar(32) NOT NULL,
  `company` varbinary(150) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `country` int(3) NOT NULL DEFAULT '0',
  `currency` varchar(10) DEFAULT NULL,
  `phone` varchar(16) DEFAULT NULL,
  `vat` varchar(60) DEFAULT NULL,
  `avatar` varchar(60) DEFAULT NULL,
  `userlevel` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  `notes` text,
  `custom_fields` text,
  `credit` decimal(10,2) NOT NULL DEFAULT '0.00',
  `lastlogin` datetime DEFAULT '0000-00-00 00:00:00',
  `lastip` varchar(16) DEFAULT '0',
  `active` enum('y','n','t','b') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;